import Generator from '../components/Generator';
export const metadata = { title: 'Configuração inicial — Many Nas Ruas' };
export default function Setup() {
  return <div className="wrap"><h1>Configuração inicial</h1>
    <p className="mut">Esta página não exige login e não guarda nada: só gera valores no seu navegador.</p>
    <ol><li>Gere os segredos abaixo e cole nas variáveis de ambiente da sua hospedagem.</li>
      <li>Use uma hospedagem Node com <b>disco persistente</b> (o app grava num arquivo). Plataformas que apagam o disco a cada publicação, como Vercel, perderiam seus dados.</li>
      <li>Publique, entre em <a href="/login" style={{ color: 'var(--ac)' }}>/login</a> e siga a aba “Primeiros passos”.</li></ol>
    <Generator /></div>;
}
