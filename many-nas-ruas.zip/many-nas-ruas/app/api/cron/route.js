import { safeEq } from '@/lib/crypto';
import { processQueue } from '@/lib/queue';
import { schedule } from '@/lib/loop';
export const dynamic = 'force-dynamic';
// Para hospedagens com cron externo (ou que "dormem"): chame com Authorization: Bearer <CRON_SECRET>.
async function run(req) {
  const s = process.env.CRON_SECRET || '', t = (req.headers.get('authorization') || '').replace('Bearer ', '');
  if (!s || !safeEq(t, s)) return new Response('Não autorizado', { status: 401 });
  return Response.json({ processed: await processQueue(schedule().batch) });
}
export const GET = run, POST = run;
