import { isAdmin, deny } from '@/lib/auth';
import { read } from '@/lib/store';
export const dynamic = 'force-dynamic';
// Só informa o NOME das variáveis ausentes, nunca os valores (exceto o token de verificação, que o admin precisa colar na Meta).
export async function GET(req) {
  if (!isAdmin(req)) return deny();
  const db = read(), e = process.env, has = k => !!(e[k] || '').trim();
  const need = ['APP_SECRET', 'ADMIN_USER', 'ADMIN_PASSWORD', 'APP_URL', 'IG_APP_ID', 'IG_APP_SECRET', 'WEBHOOK_VERIFY_TOKEN', 'DATA_DIR'];
  const missing = need.filter(k => !has(k)), base = (e.APP_URL || '').replace(/\/$/, '');
  const checks = [
    { id: 'env', label: 'Variáveis de ambiente preenchidas', done: !missing.length, hint: `Faltam: ${missing.join(', ')}. Preencha no painel de variáveis da hospedagem e reinicie.` },
    { id: 'strong', label: 'Segredos fortes e site em https', done: (e.APP_SECRET || '').length >= 32 && (e.ADMIN_PASSWORD || '').length >= 12 && base.startsWith('https://'), hint: 'Use o gerador abaixo (APP_SECRET 32+, senha 12+ caracteres) e um APP_URL que comece com https://.' },
    { id: 'disk', label: 'Armazenamento que não se apaga', done: !e.VERCEL && has('DATA_DIR'), hint: e.VERCEL ? 'Vercel não guarda arquivos entre publicações. Use hospedagem com disco persistente.' : 'Defina DATA_DIR apontando para o disco persistente da hospedagem (ex.: /data).' },
    { id: 'conn', label: 'Instagram conectado', done: !!db.account, hint: 'Aba “Conexão e cadeado” → Conectar Instagram.' },
    { id: 'hook', label: 'Webhook verificado pela Meta', done: !!db.settings.webhookVerifiedAt, hint: 'No app da Meta, cole a URL e o token abaixo em Webhooks e clique em verificar.' },
    { id: 'recv', label: 'Primeiro evento recebido da Meta', done: !!db.settings.lastWebhookAt, hint: 'Assine os campos comments, messages, messaging_postbacks e messaging_seen e comente numa publicação com uma conta de teste.' },
    { id: 'auto', label: 'Automação ativa criada', done: db.automations.some(a => a.active), hint: 'Aba “Automações” → Nova automação.' },
    { id: 'sim', label: 'Teste feito no simulador', done: !!db.settings.simulatedAt, hint: 'Aba “Simulador”: simule um comentário com a palavra-chave.' },
    { id: 'live', label: 'Envios reais liberados', done: !!db.settings.liveSends, hint: 'Só depois de testar: aba “Conexão e cadeado”.' },
  ];
  return Response.json({ checks, webhookUrl: base && `${base}/api/webhook`, redirectUrl: base && `${base}/api/oauth/callback`, verifyToken: e.WEBHOOK_VERIFY_TOKEN || '' });
}
