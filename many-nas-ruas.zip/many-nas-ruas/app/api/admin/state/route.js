import { isAdmin, deny } from '@/lib/auth';
import { read } from '@/lib/store';
import { metrics } from '@/lib/metrics';
export const dynamic = 'force-dynamic';
export async function GET(req) {
  if (!isAdmin(req)) return deny();
  const db = read();
  return Response.json({ automations: db.automations, queue: db.queue.slice(-100).reverse(), metrics: metrics(db), settings: db.settings,
    account: db.account && { igId: db.account.igId, connectedAt: db.account.connectedAt } }); // nunca devolve o token
}
