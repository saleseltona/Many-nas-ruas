import { randomUUID } from 'crypto';
import { isAdmin, deny } from '@/lib/auth';
import { mutate } from '@/lib/store';
export async function POST(req) {
  if (!isAdmin(req)) return deny();
  const a = await req.json();
  const clean = { id: a.id || randomUUID(), name: String(a.name || '').trim(), active: !!a.active, mediaId: String(a.mediaId || '').trim(),
    keywords: String(a.keywords || '').split(',').map(s => s.trim()).filter(Boolean), openingMessage: a.openingMessage, buttonLabel: a.buttonLabel, deliveryMessage: a.deliveryMessage, materialUrl: a.materialUrl };
  if (!clean.name || !clean.keywords.length || !/^https:\/\//.test(clean.materialUrl || '') || !clean.openingMessage || !clean.buttonLabel || !clean.deliveryMessage)
    return Response.json({ error: 'Preencha nome, palavras-chave, mensagens, botão e um link https.' }, { status: 400 });
  mutate(db => { const i = db.automations.findIndex(x => x.id === clean.id); i >= 0 ? (db.automations[i] = clean) : db.automations.push(clean); });
  return Response.json({ ok: true });
}
export async function DELETE(req) {
  if (!isAdmin(req)) return deny();
  const id = new URL(req.url).searchParams.get('id');
  mutate(db => { db.automations = db.automations.filter(x => x.id !== id); });
  return Response.json({ ok: true });
}
