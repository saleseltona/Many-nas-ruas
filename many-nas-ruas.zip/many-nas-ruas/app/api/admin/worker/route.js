import { isAdmin, deny } from '@/lib/auth';
import { processQueue } from '@/lib/queue';
export async function POST(req) { if (!isAdmin(req)) return deny(); return Response.json({ processed: await processQueue(20) }); }
