import { isAdmin, deny } from '@/lib/auth';
import { read, mutate } from '@/lib/store';
import { evaluate } from '@/lib/engine';
// Mesmo evaluate() do webhook. Não grava nada, não chama a Meta.
export async function POST(req) {
  if (!isAdmin(req)) return deny();
  const { text, mediaId, userId } = await req.json();
  mutate(db => { db.settings.simulatedAt = Date.now(); });
  const comment = { id: 'sim_' + Date.now(), mediaId: mediaId || undefined, text: text || '', fromId: userId || 'usuario_teste' };
  const plans = evaluate(read().automations, comment);
  return Response.json({ matched: plans.length, plans });
}
