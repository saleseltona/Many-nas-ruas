import { isAdmin, deny } from '@/lib/auth';
import { mutate } from '@/lib/store';
import { safeEq } from '@/lib/crypto';
// Cadeado: envios reais só abrem com senha + frase. Fechar é sempre livre.
export async function POST(req) {
  if (!isAdmin(req)) return deny();
  const { enable, password, phrase } = await req.json();
  if (enable) {
    if (!safeEq(password || '', process.env.ADMIN_PASSWORD || '') || phrase !== 'AUTORIZO ENVIOS REAIS') return Response.json({ error: 'Senha ou frase incorreta.' }, { status: 403 });
    if (!mutate(db => !!db.account)) return Response.json({ error: 'Conecte o Instagram antes.' }, { status: 400 });
  }
  mutate(db => { db.settings.liveSends = !!enable; db.settings.changedAt = Date.now(); });
  return Response.json({ ok: true });
}
