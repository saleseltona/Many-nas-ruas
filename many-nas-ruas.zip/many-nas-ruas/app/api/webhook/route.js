import { hmac, safeEq } from '@/lib/crypto';
import { read, mutate } from '@/lib/store';
import { evaluate, planFromPayload } from '@/lib/engine';
import { enqueue, event, processQueue } from '@/lib/queue';
export const dynamic = 'force-dynamic';

export async function GET(req) { // verificação do webhook pela Meta
  const p = new URL(req.url).searchParams;
  if (p.get('hub.mode') === 'subscribe' && p.get('hub.verify_token') === process.env.WEBHOOK_VERIFY_TOKEN) { mutate(db => { db.settings.webhookVerifiedAt = Date.now(); }); return new Response(p.get('hub.challenge')); }
  return new Response('Forbidden', { status: 403 });
}
export async function POST(req) {
  const raw = await req.text(); // HMAC sobre o corpo bruto
  const sig = (req.headers.get('x-hub-signature-256') || '').replace('sha256=', '');
  if (!process.env.IG_APP_SECRET || !safeEq(sig, hmac(raw, process.env.IG_APP_SECRET))) return new Response('Assinatura inválida', { status: 401 });
  mutate(db => { db.settings.lastWebhookAt = Date.now(); });
  const body = JSON.parse(raw); const { automations } = read();
  for (const entry of body.entry || []) {
    for (const ch of entry.changes || []) {
      if (ch.field !== 'comments' || ch.value?.from?.id === entry.id) continue; // ignora comentários próprios
      const v = ch.value, comment = { id: v.id, mediaId: v.media?.id, text: v.text, fromId: v.from?.id };
      for (const plan of evaluate(automations, comment))
        if (enqueue({ dedupKey: plan.dedupKey, automationId: plan.automationId, ...plan.opening })) event('activation', { automationId: plan.automationId });
    }
    for (const m of entry.messaging || []) {
      const uid = m.sender?.id;
      if (m.read) event('open', { key: `open:${uid}`, userId: uid });
      if (m.postback?.payload) {
        const p = planFromPayload(automations, m.postback.payload); if (!p) continue;
        event('open', { key: `open:${uid}`, userId: uid });
        if (enqueue({ dedupKey: `deliver:${p.automationId}:${uid}`, automationId: p.automationId, kind: 'delivery', recipientId: uid, text: p.deliveryMessage, button: 'Abrir material', url: p.materialUrl }))
          event('click', { key: `click:${p.automationId}:${uid}`, automationId: p.automationId });
      }
    }
  }
  await processQueue(5);
  return new Response('ok');
}
