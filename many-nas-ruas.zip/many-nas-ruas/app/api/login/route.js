import { checkLogin, makeSession, COOKIE } from '@/lib/auth';
export async function POST(req) {
  const { user, password } = await req.json();
  if (!checkLogin(user || '', password || '')) return Response.json({ error: 'Usuário ou senha incorretos' }, { status: 401 });
  const res = Response.json({ ok: true });
  res.headers.append('Set-Cookie', `${COOKIE}=${makeSession()}; Path=/; HttpOnly; SameSite=Lax; Max-Age=43200${process.env.NODE_ENV === 'production' ? '; Secure' : ''}`);
  return res;
}
export async function DELETE() { const r = Response.json({ ok: true }); r.headers.append('Set-Cookie', `${COOKIE}=; Path=/; Max-Age=0`); return r; }
