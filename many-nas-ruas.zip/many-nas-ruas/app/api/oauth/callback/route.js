import { isAdmin } from '@/lib/auth';
import { exchangeCode } from '@/lib/meta';
import { enc, safeEq } from '@/lib/crypto';
import { mutate } from '@/lib/store';
export async function GET(req) {
  if (!isAdmin(req)) return new Response('Não autorizado', { status: 401 });
  const p = new URL(req.url).searchParams, st = req.cookies.get('mnr_state')?.value;
  if (!st || !safeEq(p.get('state') || '', st)) return new Response('State inválido', { status: 400 });
  try {
    const { token, igId, expiresIn } = await exchangeCode(p.get('code'));
    mutate(db => { db.account = { igId, tokenEnc: enc(token), connectedAt: Date.now(), expiresAt: Date.now() + (expiresIn || 0) * 1000 }; }); // token criptografado em repouso
  } catch (e) { return new Response('Falha no OAuth: ' + e.message, { status: 400 }); }
  return Response.redirect(`${process.env.APP_URL}/admin`);
}
