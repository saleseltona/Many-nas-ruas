import { isAdmin } from '@/lib/auth';
import { authUrl } from '@/lib/meta';
import { randomBytes } from 'crypto';
export async function GET(req) {
  if (!isAdmin(req)) return new Response('Não autorizado', { status: 401 });
  const state = randomBytes(16).toString('hex');
  const res = Response.redirect(authUrl(state));
  res.headers.append('Set-Cookie', `mnr_state=${state}; Path=/; HttpOnly; SameSite=Lax; Max-Age=600`);
  return res;
}
