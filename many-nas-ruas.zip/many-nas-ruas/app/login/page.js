'use client';
import { useState } from 'react';
export default function Login() {
  const [err, setErr] = useState('');
  async function go(e) {
    e.preventDefault(); const f = new FormData(e.target);
    const r = await fetch('/api/login', { method: 'POST', body: JSON.stringify({ user: f.get('user'), password: f.get('password') }) });
    r.ok ? (location.href = '/admin') : setErr((await r.json()).error);
  }
  return <div className="wrap" style={{ maxWidth: 400, paddingTop: '15vh' }}>
    <h1>Many Nas Ruas</h1><p className="mut">Entre para gerenciar as automações.</p>
    <form onSubmit={go} className="card"><label>Usuário<input name="user" autoComplete="username" required /></label>
      <label>Senha<input name="password" type="password" autoComplete="current-password" required /></label>
      {err && <p className="err" role="alert">{err}</p>}<button className="p" style={{ width: '100%' }}>Entrar</button></form><p className="mut">Primeira vez? <a href="/setup" style={{ color: 'var(--ac)' }}>Gere seus segredos</a>.</p></div>;
}
