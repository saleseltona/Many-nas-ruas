import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { validSession, COOKIE } from '@/lib/auth';
import Panel from './Panel';
export const dynamic = 'force-dynamic';
export default function Admin() { if (!validSession(cookies().get(COOKIE)?.value)) redirect('/login'); return <Panel />; }
