'use client';
import { useEffect, useState, useCallback } from 'react';
import Generator, { Copy } from '../components/Generator';
const api = (u, m = 'GET', b) => fetch(u, { method: m, body: b && JSON.stringify(b) }).then(async r => ({ ok: r.ok, ...(await r.json()) }));
const empty = { name: '', active: true, mediaId: '', keywords: '', openingMessage: 'Oi! Vi seu comentário 💛 Toque no botão para receber o material.', buttonLabel: 'Quero o material', deliveryMessage: 'Aqui está o seu material. Bom proveito!', materialUrl: 'https://' };
const pct = n => (n * 100).toFixed(1).replace('.', ',') + '%';

export default function Panel() {
  const [tab, setTab] = useState('p'); const [s, setS] = useState(null);
  const load = useCallback(async () => { const r = await api('/api/admin/state'); if (r.ok) setS(r); else location.href = '/login'; }, []);
  useEffect(() => { load(); const t = setInterval(load, 8000); return () => clearInterval(t); }, [load]);
  if (!s) return <div className="wrap">Carregando…</div>;
  const tabs = [['p', 'Primeiros passos'], ['m', 'Métricas'], ['a', 'Automações'], ['s', 'Simulador'], ['f', 'Fila'], ['c', 'Conexão e cadeado']];
  return <div className="wrap">
    <header><h1>Many Nas Ruas</h1><div className="row">
      <span className={s.settings.liveSends ? 'ok' : 'err'}>{s.settings.liveSends ? '● Envios reais liberados' : '● Envios reais bloqueados'}</span>
      <button onClick={async () => { await api('/api/login', 'DELETE'); location.href = '/login'; }}>Sair</button></div></header>
    <nav>{tabs.map(([k, l]) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{l}</button>)}</nav>
    {tab === 'p' && <Setup />}
    {tab === 'm' && <Metrics m={s.metrics} />}
    {tab === 'a' && <Automations list={s.automations} reload={load} />}
    {tab === 's' && <Simulator />}
    {tab === 'f' && <Queue q={s.queue} reload={load} />}
    {tab === 'c' && <Connection s={s} reload={load} />}
  </div>;
}

function Metrics({ m }) {
  const items = [['Ativações', m.activations, 'Comentários que acionaram uma automação e entraram na fila (um por comentário e automação).'],
    ['Aberturas', m.opens, 'Pessoas únicas que leram a mensagem ou clicaram no botão (clicar implica abrir).'],
    ['Cliques', m.clicks, 'Pessoas únicas que tocaram no botão da mensagem.'], ['CTR', pct(m.ctr), 'Cliques ÷ aberturas.']];
  return <div className="grid">{items.map(([t, v, d]) => <div className="card" key={t}><h3>{t}</h3><div className="big">{v}</div><p className="mut">{d}</p></div>)}</div>;
}

function Automations({ list, reload }) {
  const [f, setF] = useState(null); const [err, setErr] = useState('');
  const set = k => e => setF({ ...f, [k]: e.target.value });
  async function save(e) { e.preventDefault(); const r = await api('/api/admin/automations', 'POST', f); if (r.ok) { setF(null); setErr(''); reload(); } else setErr(r.error); }
  if (f) return <form className="card" onSubmit={save}>
    <h2>{f.id ? 'Editar automação' : 'Nova automação'}</h2>
    <label>Nome<input value={f.name} onChange={set('name')} required /></label>
    <label>Palavras-chave (separadas por vírgula)<input value={f.keywords} onChange={set('keywords')} placeholder="quero, material, ebook" required /></label>
    <label>ID da publicação (vazio = qualquer publicação)<input value={f.mediaId} onChange={set('mediaId')} /></label>
    <label>Mensagem inicial (resposta ao comentário)<textarea rows={3} value={f.openingMessage} onChange={set('openingMessage')} /></label>
    <label>Texto do botão<input value={f.buttonLabel} onChange={set('buttonLabel')} maxLength={20} /></label>
    <label>Mensagem de entrega (depois do clique)<textarea rows={3} value={f.deliveryMessage} onChange={set('deliveryMessage')} /></label>
    <label>Link do material (https)<input value={f.materialUrl} onChange={set('materialUrl')} /></label>
    <label className="row"><input type="checkbox" style={{ width: 'auto', margin: 0 }} checked={f.active} onChange={e => setF({ ...f, active: e.target.checked })} /> Ativa</label>
    {err && <p className="err" role="alert">{err}</p>}
    <div className="row"><button className="p">Salvar</button><button type="button" onClick={() => setF(null)}>Cancelar</button></div></form>;
  return <><button className="p" onClick={() => setF({ ...empty, keywords: '' })}>Nova automação</button>
    {!list.length && <p className="mut">Nenhuma automação ainda. Crie a primeira para começar a responder comentários.</p>}
    {list.map(a => <div className="card" key={a.id} style={{ marginTop: 12 }}><h3>{a.name} <span className={a.active ? 'ok' : 'mut'}>{a.active ? '(ativa)' : '(pausada)'}</span></h3>
      <p className="mut">Palavras: {a.keywords.join(', ')} · Publicação: {a.mediaId || 'todas'}</p>
      <div className="row"><button onClick={() => setF({ ...a, keywords: a.keywords.join(', ') })}>Editar</button>
        <button className="d" onClick={async () => { if (confirm('Excluir esta automação?')) { await api('/api/admin/automations?id=' + a.id, 'DELETE'); reload(); } }}>Excluir</button></div></div>)}</>;
}

function Simulator() {
  const [t, setT] = useState(''); const [media, setMedia] = useState(''); const [r, setR] = useState(null);
  return <div className="card"><h2>Simulador</h2><p className="mut">Roda o mesmo motor de regras do webhook. Não grava nada e não chama a Meta.</p>
    <label>Comentário de teste<textarea rows={2} value={t} onChange={e => setT(e.target.value)} placeholder="Quero o material!" /></label>
    <label>ID da publicação (opcional)<input value={media} onChange={e => setMedia(e.target.value)} /></label>
    <button className="p" onClick={async () => setR(await api('/api/admin/simulate', 'POST', { text: t, mediaId: media }))}>Simular comentário</button>
    {r && (r.matched ? r.plans.map(p => <div className="card" key={p.dedupKey} style={{ marginTop: 12 }}>
      <p className="ok">Ativou “{p.automationName}”</p>
      <p><b>1. Resposta privada:</b> {p.opening.text}<br /><span className="mut">[botão: {p.opening.button}]</span></p>
      <p><b>2. Após o clique:</b> {p.onClick.text}<br /><span className="mut">[botão: {p.onClick.button} → {p.onClick.url}]</span></p></div>)
      : <p className="mut" style={{ marginTop: 12 }}>Nenhuma automação ativada por esse comentário.</p>)}</div>;
}

function Queue({ q, reload }) {
  return <div className="card"><div className="row" style={{ justifyContent: 'space-between' }}><h2>Fila de envio</h2>
    <button onClick={async () => { await api('/api/admin/worker', 'POST'); reload(); }}>Processar agora</button></div>
    {!q.length ? <p className="mut">A fila está vazia. Os comentários que acionarem uma automação aparecem aqui.</p> :
      <div className="tbl"><table><thead><tr><th>Tipo</th><th>Destino</th><th>Status</th><th>Tentativas</th><th>Erro</th></tr></thead>
        <tbody>{q.map(i => <tr key={i.id}><td>{i.kind === 'opening' ? 'Resposta' : 'Entrega'}</td><td>{i.recipientId}</td>
          <td className={i.status === 'sent' ? 'ok' : i.status === 'failed' ? 'err' : ''}>{{ dry_run: 'simulado (bloqueado)', sent: 'enviado', pending: 'pendente', reserved: 'reservado', failed: 'falhou' }[i.status]}</td><td>{i.attempts}</td><td>{i.error}</td></tr>)}</tbody></table></div>}
    <p className="mut">Itens criados com o cadeado fechado ficam como “simulado” e não são reenviados depois, de propósito.</p></div>;
}

function Connection({ s, reload }) {
  const [pw, setPw] = useState(''); const [ph, setPh] = useState(''); const [err, setErr] = useState('');
  const on = s.settings.liveSends;
  async function toggle(enable) { const r = await api('/api/admin/lock', 'POST', { enable, password: pw, phrase: ph }); if (r.ok) { setErr(''); setPw(''); setPh(''); reload(); } else setErr(r.error); }
  return <><div className="card"><h2>Conta do Instagram</h2>
    {s.account ? <p className="ok">Conectada (ID {s.account.igId}). O token fica criptografado em repouso.</p> : <p className="mut">Nenhuma conta conectada.</p>}
    <a href="/api/oauth/start"><button className="p">{s.account ? 'Reconectar' : 'Conectar Instagram'}</button></a></div>
    <div className={'card lock' + (on ? ' open' : '')}><h2>Cadeado de envios reais</h2>
      {on ? <><p className="ok">Aberto: mensagens reais estão sendo enviadas pela Meta.</p><button className="d" onClick={() => toggle(false)}>Fechar cadeado</button></>
        : <><p>Fechado: nada é enviado à Meta. Para liberar, confirme sua senha e digite <b>AUTORIZO ENVIOS REAIS</b>.</p>
          <label>Senha<input type="password" value={pw} onChange={e => setPw(e.target.value)} /></label>
          <label>Frase de autorização<input value={ph} onChange={e => setPh(e.target.value)} /></label>
          <button className="p" onClick={() => toggle(true)}>Autorizar envios reais</button></>}
      {err && <p className="err" role="alert">{err}</p>}</div></>;
}

function Setup() {
  const [d, setD] = useState(null);
  const load = useCallback(async () => setD(await api('/api/admin/setup')), []);
  useEffect(() => { load(); const t = setInterval(load, 6000); return () => clearInterval(t); }, [load]);
  if (!d || !d.checks) return <p>Carregando…</p>;
  const n = d.checks.filter(c => c.done).length;
  return <>
    <div className="card"><h2>Primeiros passos</h2>
      <p className="mut">{n} de {d.checks.length} prontos. Os itens se marcam sozinhos a cada poucos segundos.</p>
      <div className="bar" role="progressbar" aria-valuenow={n} aria-valuemax={d.checks.length}><i style={{ width: `${(n / d.checks.length) * 100}%` }} /></div>
      {d.checks.map(c => <div className="chk" key={c.id}><span className={c.done ? 'ok' : 'mut'} aria-hidden="true">{c.done ? '✔' : '○'}</span>
        <div><b>{c.label}</b> <span className="mut">{c.done ? '(pronto)' : '(pendente)'}</span>{!c.done && <p className="mut" style={{ margin: '2px 0 0' }}>{c.hint}</p>}</div></div>)}
      <button style={{ marginTop: 12 }} onClick={load}>Verificar de novo</button></div>
    <div className="card"><h3>Para colar no painel da Meta</h3>
      <Copy label="URL de callback do webhook" v={d.webhookUrl} /><Copy label="Token de verificação" v={d.verifyToken} /><Copy label="URI de redirecionamento do OAuth" v={d.redirectUrl} /></div>
    <Generator /></>;
}
