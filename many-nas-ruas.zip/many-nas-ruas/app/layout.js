import './globals.css';
import { BRAND } from '../lib/brand';
export const metadata = {
  title: BRAND.name, description: BRAND.description,
  applicationName: BRAND.name,
  // iPhone: nome sob o ícone, modo tela cheia e ícone de 180x180 (o iOS ignora o manifesto para o ícone).
  appleWebApp: { capable: true, title: BRAND.short, statusBarStyle: 'black' },
  icons: { apple: [{ url: '/apple-touch-icon.png', sizes: '180x180', type: 'image/png' }] },
  formatDetection: { telephone: false },
};
export const viewport = { themeColor: BRAND.bg, colorScheme: 'dark', width: 'device-width', initialScale: 1 };
export default function L({ children }) { return <html lang="pt-BR"><body>{children}</body></html>; }
