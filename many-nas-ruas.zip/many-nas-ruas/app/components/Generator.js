'use client';
import { useState, useEffect } from 'react';
const AL = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'; // sem caracteres ambíguos (0/O, 1/l/I)
const rnd = n => { const a = new Uint32Array(1), lim = Math.floor(2 ** 32 / n) * n; let x; do { crypto.getRandomValues(a); x = a[0]; } while (x >= lim); return x % n; };
const hex = n => [...crypto.getRandomValues(new Uint8Array(n))].map(b => b.toString(16).padStart(2, '0')).join('');
const make = () => ({ APP_SECRET: hex(32), WEBHOOK_VERIFY_TOKEN: hex(16), CRON_SECRET: hex(24), ADMIN_PASSWORD: Array.from({ length: 20 }, () => AL[rnd(AL.length)]).join('') });

export function Copy({ label, v }) {
  const [ok, setOk] = useState(false);
  return <div style={{ marginBottom: 12 }}><label>{label}</label>
    <div className="row"><code className="code" style={{ flex: 1 }}>{v || '(defina APP_URL primeiro)'}</code>
      <button disabled={!v} onClick={async () => { try { await navigator.clipboard.writeText(v); setOk(true); setTimeout(() => setOk(false), 1500); } catch { } }}>{ok ? 'Copiado' : 'Copiar'}</button></div></div>;
}

export default function Generator() {
  const [v, setV] = useState(null);
  useEffect(() => setV(make()), []); // só no navegador, depois de carregar
  if (!v) return null;
  return <div className="card"><h3>Gerador de segredos</h3>
    <p className="mut">Os valores são criados neste navegador (Web Crypto) e não são enviados a nenhum servidor.</p>
    {Object.entries(v).map(([k, x]) => <Copy key={k} label={k} v={x} />)}
    <Copy label="Tudo junto (cole no painel de variáveis da hospedagem)" v={Object.entries(v).map(([k, x]) => `${k}=${x}`).join('\n')} />
    <button onClick={() => setV(make())}>Gerar novos</button>
    <p className="mut">Guarde num gerenciador de senhas antes de sair desta tela: não há como recuperar. Trocar o <b>APP_SECRET</b> depois impede ler o token do Instagram já salvo, e será preciso reconectar a conta.</p>
    <p className="mut">Você mesmo preenche: <b>ADMIN_USER</b>, <b>APP_URL</b> (endereço https do site), <b>IG_APP_ID</b> e <b>IG_APP_SECRET</b> (painel da Meta) e <b>DATA_DIR</b> (pasta do disco persistente, ex.: /data).</p></div>;
}
