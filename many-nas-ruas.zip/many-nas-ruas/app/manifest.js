import { BRAND } from '../lib/brand';
// Android/Chrome: nome, ícones e modo "app" ao adicionar à tela inicial.
export default function manifest() {
  return {
    name: BRAND.name, short_name: BRAND.short, description: BRAND.description, lang: 'pt-BR',
    id: '/', start_url: '/admin', scope: '/', display: 'standalone', orientation: 'portrait',
    background_color: BRAND.bg, theme_color: BRAND.bg,
    icons: [
      { src: '/icons/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
      { src: '/icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
      { src: '/icons/maskable-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
    ],
  };
}
