"""Gera todos os ícones a partir de design/emblema-original.png (rode na raiz: python3 scripts/gerar-icones.py).
Transparente onde a plataforma aceita (Android "any", favicon); fundo branco sólido onde exige
(iOS apple-touch-icon e Android maskable, que o sistema recorta e preenche)."""
import numpy as np
from math import hypot
from PIL import Image, ImageFilter
from scipy import ndimage as ndi

rgb = Image.open('design/emblema-original.png').convert('RGB')
a = np.asarray(rgb).astype(int); m = a.min(axis=2)
lab, _ = ndi.label(m >= 228)                                  # regiões quase brancas...
borda = (set(lab[0]) | set(lab[-1]) | set(lab[:, 0]) | set(lab[:, -1])) - {0}
fundo = np.isin(lab, list(borda))                             # ...só as ligadas à borda são fundo (o branco do robô fica)
mask = Image.fromarray((fundo * 255).astype('uint8')).filter(ImageFilter.MaxFilter(5)).filter(ImageFilter.GaussianBlur(1.2))
rgba = rgb.copy(); rgba.putalpha(mask.point(lambda v: 255 - v))
box = rgba.getchannel('A').point(lambda v: 255 if v > 8 else 0).getbbox()
arte_t, arte_o = rgba.crop(box), rgb.crop(box)                # mesma área: versão transparente e versão original

def encaixar(arte, n, escala=None, diag=None, fundo_cor=None):
    w, h = arte.size
    k = diag * n / hypot(w, h) if diag else escala * n / max(w, h)
    a2 = arte.resize((round(w * k), round(h * k)), Image.LANCZOS)
    tela = Image.new('RGB', (n, n), fundo_cor) if fundo_cor else Image.new('RGBA', (n, n), (0, 0, 0, 0))
    pos = ((n - a2.width) // 2, (n - a2.height) // 2)
    tela.paste(a2, pos, a2 if a2.mode == 'RGBA' else None); return tela

BRANCO = (255, 255, 255)
for n in (192, 512): encaixar(arte_t, n, escala=.92).save(f'public/icons/icon-{n}.png')                      # Android "any": transparente
encaixar(arte_o, 512, diag=.80, fundo_cor=BRANCO).save('public/icons/maskable-512.png')                       # Android maskable: sólido + zona segura
encaixar(arte_o, 180, escala=.90, fundo_cor=BRANCO).save('public/apple-touch-icon.png')                       # iOS: sólido
encaixar(arte_t, 64, escala=.96).save('app/favicon.ico', sizes=[(16, 16), (32, 32), (48, 48)])               # aba do navegador: transparente
