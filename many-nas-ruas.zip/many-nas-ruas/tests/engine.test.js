import { describe, it, expect } from 'vitest';
import { evaluate, planFromPayload } from '../lib/engine';
const a = { id: '1', name: 'T', active: true, mediaId: '', keywords: ['quero'], openingMessage: 'o', buttonLabel: 'b', deliveryMessage: 'd', materialUrl: 'https://x.co' };
const c = (text, extra = {}) => ({ id: 'c1', mediaId: 'm1', text, fromId: 'u1', ...extra });
describe('motor de regras', () => {
  it('ignora acento e caixa', () => expect(evaluate([a], c('QUERÓ!!'))).toHaveLength(1));
  it('exige a palavra inteira', () => expect(evaluate([a], c('queroso'))).toHaveLength(0));
  it('respeita a publicação escolhida', () => {
    expect(evaluate([{ ...a, mediaId: 'm2' }], c('quero'))).toHaveLength(0);
    expect(evaluate([{ ...a, mediaId: 'm1' }], c('quero'))).toHaveLength(1);
  });
  it('ignora automação pausada', () => expect(evaluate([{ ...a, active: false }], c('quero'))).toHaveLength(0));
  it('gera chave de deduplicação estável', () => expect(evaluate([a], c('quero'))[0].dedupKey).toBe(evaluate([a], c('quero'))[0].dedupKey));
  it('resolve o payload do botão', () => expect(planFromPayload([a], 'ck:1').materialUrl).toBe('https://x.co'));
});
