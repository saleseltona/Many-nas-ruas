import { describe, it, expect, beforeEach } from 'vitest';
import { enc, dec, hmac, safeEq } from '../lib/crypto';
beforeEach(() => { process.env.APP_SECRET = 'k'.repeat(32); });
describe('criptografia', () => {
  it('ida e volta', () => expect(dec(enc('segredo'))).toBe('segredo'));
  it('detecta adulteração', () => { const [iv, tag, d] = enc('segredo').split('.'); expect(() => dec([iv, tag, Buffer.from('xx').toString('base64')].join('.'))).toThrow(); });
  it('falha com outra chave', () => { const s = enc('segredo'); process.env.APP_SECRET = 'z'.repeat(32); expect(() => dec(s)).toThrow(); });
  it('compara HMAC em tempo constante', () => { expect(safeEq(hmac('a', 'k'), hmac('a', 'k'))).toBe(true); expect(safeEq(hmac('a', 'k'), hmac('b', 'k'))).toBe(false); });
});
