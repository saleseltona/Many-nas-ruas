import { describe, it, expect } from 'vitest';
import { readFileSync, existsSync } from 'fs';
import manifest from '../app/manifest';
const wh = f => { const b = readFileSync(f); return [b.readUInt32BE(16), b.readUInt32BE(20)]; }; // cabeçalho IHDR do PNG
describe('instalação na tela inicial', () => {
  const m = manifest();
  it('tem nome, nome curto (≤12) e modo app', () => { expect(m.name).toBe('Many Nas Ruas'); expect(m.short_name.length).toBeLessThanOrEqual(12); expect(m.display).toBe('standalone'); });
  it('declara ícones 192, 512 e maskable que existem com o tamanho certo', () => {
    for (const i of m.icons) { const f = 'public' + i.src, n = Number(i.sizes.split('x')[0]); expect(existsSync(f)).toBe(true); expect(wh(f)).toEqual([n, n]); }
    expect(m.icons.some(i => i.purpose === 'maskable')).toBe(true);
  });
  it('usa transparência só onde a plataforma aceita', () => {
    const tipo = f => readFileSync(f)[25]; // cor do PNG: 6 = RGBA (transparente), 2 = RGB (sólido)
    expect([tipo('public/icons/icon-192.png'), tipo('public/icons/icon-512.png')]).toEqual([6, 6]);
    expect([tipo('public/icons/maskable-512.png'), tipo('public/apple-touch-icon.png')]).toEqual([2, 2]);
  });
  it('tem o ícone do iPhone com 180x180', () => expect(wh('public/apple-touch-icon.png')).toEqual([180, 180]));
});
