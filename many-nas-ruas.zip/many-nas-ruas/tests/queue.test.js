import { describe, it, expect, beforeEach, vi } from 'vitest';
import { mkdtempSync } from 'fs'; import { tmpdir } from 'os'; import { join } from 'path';
import * as meta from '../lib/meta';
import { enqueue, processQueue } from '../lib/queue';
import { mutate, read } from '../lib/store';
import { enc } from '../lib/crypto';
import { schedule } from '../lib/loop';
vi.mock('../lib/meta', () => ({ send: vi.fn() }));
const item = k => ({ dedupKey: k, kind: 'opening', commentId: 'c', recipientId: 'u', text: 't', button: 'b', payload: 'ck:1' });
const unlock = () => mutate(db => { db.account = { igId: '1', tokenEnc: enc('tok') }; db.settings.liveSends = true; });
beforeEach(() => { process.env.APP_SECRET = 's'.repeat(32); process.env.DATA_DIR = mkdtempSync(join(tmpdir(), 'mnr-')); vi.mocked(meta.send).mockReset(); });
describe('fila', () => {
  it('deduplica por chave', () => { expect(enqueue(item('k'))).toBeTruthy(); expect(enqueue(item('k'))).toBeNull(); expect(read().queue).toHaveLength(1); });
  it('com o cadeado fechado nunca chama a Meta', async () => {
    enqueue(item('k')); const r = await processQueue();
    expect(r[0].status).toBe('dry_run'); expect(meta.send).not.toHaveBeenCalled();
  });
  it('com o cadeado aberto envia uma única vez', async () => {
    unlock(); enqueue(item('k')); await processQueue(); await processQueue();
    expect(meta.send).toHaveBeenCalledTimes(1); expect(meta.send).toHaveBeenCalledWith('1', 'tok', expect.objectContaining({ dedupKey: 'k' }));
  });
  it('não pega item já reservado', async () => {
    enqueue(item('k')); mutate(db => { db.queue[0].status = 'reserved'; db.queue[0].lease = Date.now() + 60000; });
    expect(await processQueue()).toHaveLength(0);
  });
  it('falha espera antes de repetir e desiste na 3ª tentativa', async () => {
    unlock(); vi.mocked(meta.send).mockRejectedValue(new Error('x')); enqueue(item('k'));
    await processQueue(); await processQueue();
    expect(meta.send).toHaveBeenCalledTimes(1);
    for (let i = 0; i < 2; i++) { mutate(db => db.queue.forEach(q => { q.notBefore = 0; })); await processQueue(); }
    expect(meta.send).toHaveBeenCalledTimes(3); expect(read().queue[0].status).toBe('failed');
  });
  it('limita o ritmo configurado', () => {
    process.env.QUEUE_INTERVAL_SECONDS = '1'; process.env.QUEUE_BATCH = '999';
    expect(schedule()).toEqual({ every: 10, batch: 20 });
    delete process.env.QUEUE_INTERVAL_SECONDS; delete process.env.QUEUE_BATCH;
    expect(schedule()).toEqual({ every: 60, batch: 5 });
  });
});
