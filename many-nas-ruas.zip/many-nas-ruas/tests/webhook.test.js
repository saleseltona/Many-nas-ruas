import { describe, it, expect, beforeEach } from 'vitest';
import { mkdtempSync } from 'fs'; import { tmpdir } from 'os'; import { join } from 'path';
import { GET, POST } from '../app/api/webhook/route';
import { hmac } from '../lib/crypto';
import { mutate, read } from '../lib/store';
import { metrics } from '../lib/metrics';
const auto = { id: '1', name: 'T', active: true, mediaId: '', keywords: ['quero'], openingMessage: 'o', buttonLabel: 'b', deliveryMessage: 'd', materialUrl: 'https://x.co' };
const body = JSON.stringify({ entry: [{ id: 'ig', changes: [{ field: 'comments', value: { id: 'c1', text: 'quero!', media: { id: 'm' }, from: { id: 'u' } } }] }] });
const post = (raw, sig) => POST(new Request('http://x/api/webhook', { method: 'POST', headers: { 'x-hub-signature-256': sig }, body: raw }));
beforeEach(() => { Object.assign(process.env, { APP_SECRET: 's'.repeat(32), IG_APP_SECRET: 'segredo', WEBHOOK_VERIFY_TOKEN: 'tk', DATA_DIR: mkdtempSync(join(tmpdir(), 'mnr-')) }); mutate(db => { db.automations.push(auto); }); });
describe('webhook', () => {
  it('rejeita assinatura inválida', async () => { expect((await post(body, 'sha256=00')).status).toBe(401); expect(read().queue).toHaveLength(0); });
  it('aceita assinatura válida e não duplica reentregas', async () => {
    const sig = 'sha256=' + hmac(body, 'segredo');
    expect((await post(body, sig)).status).toBe(200); await post(body, sig);
    expect(read().queue).toHaveLength(1); expect(metrics(read()).activations).toBe(1);
  });
  it('verifica o token de inscrição', async () => {
    expect((await GET(new Request('http://x/api/webhook?hub.mode=subscribe&hub.verify_token=tk&hub.challenge=123'))).status).toBe(200);
    expect((await GET(new Request('http://x/api/webhook?hub.mode=subscribe&hub.verify_token=no&hub.challenge=1'))).status).toBe(403);
  });
});
